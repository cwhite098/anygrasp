# anygrasp

```
python generate_grasps.py --mesh <path_to_stl> --visualise
```
to generate some grasps. Use `--n_grasps` to generate more than 1.
